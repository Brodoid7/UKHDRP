const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../lib/db');
const perms = require('../lib/perms');
const { embed, log, isStaff, EPH } = require('../lib/util');

const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const wordRe = (w) => new RegExp(`(^|[^\\p{L}\\p{N}])${esc(w)}($|[^\\p{L}\\p{N}])`, 'iu');

async function apply(guild, member, why) {
  const act = perms.serverBlacklist(guild).action;
  try { if (act === 'ban') await member.ban({ reason: why }); else await member.kick(why); } catch { /* hierarchy */ }
}

module.exports = {
  init(client) {
    // Server blacklist: remove blacklisted users the moment they join
    client.on('guildMemberAdd', async (m) => {
      const e = perms.serverBlacklist(m.guild).users[m.id];
      if (!e || perms.isWhitelisted(m.guild, m.id)) return;
      await apply(m.guild, m, `Blacklisted: ${e.reason}`);
      log(m.guild, embed('err', '⛔ Blacklisted user removed', `${m.user.tag} (${m.id})\n**Reason:** ${e.reason}`));
    });
    // Word blacklist
    client.on('messageCreate', async (msg) => {
      if (!msg.guild || msg.author.bot || !msg.member || !msg.content) return;
      const words = perms.serverBlacklist(msg.guild).words;
      if (!words.length || isStaff(msg.member) || perms.isWhitelisted(msg.guild, msg.author.id)) return;
      const hit = words.find((w) => wordRe(w).test(msg.content));
      if (!hit) return;
      msg.delete().catch(() => {});
      msg.channel.send(`🚫 ${msg.author}, that word isn't allowed here.`).then((m) => setTimeout(() => m.delete().catch(() => {}), 5000)).catch(() => {});
      log(msg.guild, embed('warn', '🚫 Blacklisted word', `${msg.author} in ${msg.channel}\n**Word:** ||${hit}||`));
    });
  },
  commands: [{
    data: new SlashCommandBuilder().setName('blacklist').setDescription('Blacklist systems')
      // ---- bot-wide
      .addSubcommandGroup((g) => g.setName('bot').setDescription('Block a user from using the bot anywhere (bot admin+)')
        .addSubcommand((s) => s.setName('add').setDescription('Blacklist from the bot')
          .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))
          .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(true).setMaxLength(200)))
        .addSubcommand((s) => s.setName('remove').setDescription('Un-blacklist').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
        .addSubcommand((s) => s.setName('list').setDescription('List')))
      // ---- per-server users
      .addSubcommandGroup((g) => g.setName('server').setDescription('Server blacklist: auto-removed on join, blocked from modmail & applications (Manage Server)')
        .addSubcommand((s) => s.setName('add').setDescription('Blacklist a user')
          .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))
          .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(true).setMaxLength(200)))
        .addSubcommand((s) => s.setName('remove').setDescription('Remove').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
        .addSubcommand((s) => s.setName('action').setDescription('What happens when they join').addStringOption((o) => o.setName('type').setDescription('Action').setRequired(true).addChoices({ name: 'ban', value: 'ban' }, { name: 'kick', value: 'kick' })))
        .addSubcommand((s) => s.setName('list').setDescription('List')))
      // ---- words
      .addSubcommandGroup((g) => g.setName('word').setDescription('Blocked words/phrases (Manage Server)')
        .addSubcommand((s) => s.setName('add').setDescription('Block a word or phrase').addStringOption((o) => o.setName('word').setDescription('Word/phrase').setRequired(true).setMaxLength(60)))
        .addSubcommand((s) => s.setName('remove').setDescription('Unblock').addStringOption((o) => o.setName('word').setDescription('Word/phrase').setRequired(true)))
        .addSubcommand((s) => s.setName('list').setDescription('List'))),
    async execute(i, client) {
      const group = i.options.getSubcommandGroup(), sub = i.options.getSubcommand();
      const none = { parse: [] };

      if (group === 'bot') {
        if (perms.denyUnless(i, 'admin')) return;
        const bl = perms.botBlacklist();
        if (sub === 'list') return i.reply({ flags: EPH, allowedMentions: none, embeds: [embed('info', '⛔ Bot blacklist', Object.entries(bl).map(([id, e]) => `<@${id}> - ${e.reason}`).join('\n').slice(0, 4000) || 'Empty.')] });
        const u = i.options.getUser('user');
        if (sub === 'add') {
          if (perms.rankOf(u.id) >= 1 || perms.isGlobalWhitelisted(u.id) || u.id === client.user.id) return i.reply({ flags: EPH, content: '🔒 You can\'t blacklist that user.' });
          bl[u.id] = { reason: i.options.getString('reason'), by: i.user.id, ts: Date.now() };
        } else delete bl[u.id];
        db.save();
        return i.reply({ flags: EPH, allowedMentions: none, embeds: [embed('ok', null, sub === 'add' ? `⛔ <@${u.id}> can no longer use the bot.` : `✅ <@${u.id}> un-blacklisted.`)] });
      }

      if (!i.memberPermissions.has(PermissionFlagsBits.ManageGuild)) return i.reply({ flags: EPH, content: '🔒 Needs Manage Server.' });
      const cfg = perms.serverBlacklist(i.guild);

      if (group === 'word') {
        const w = i.options.getString('word')?.toLowerCase().trim();
        if (sub === 'add' && !cfg.words.includes(w)) cfg.words.push(w);
        if (sub === 'remove') cfg.words = cfg.words.filter((x) => x !== w);
        db.set(i.guild.id, 'blacklist', cfg);
        return i.reply({ flags: EPH, embeds: [embed(sub === 'list' ? 'info' : 'ok', '🚫 Blocked words', cfg.words.map((x) => `||${x}||`).join(', ') || 'None.')] });
      }

      // server users
      if (sub === 'action') { cfg.action = i.options.getString('type'); db.save(); return i.reply({ flags: EPH, embeds: [embed('ok', null, `Blacklisted users will be ${cfg.action === 'ban' ? 'banned' : 'kicked'} on join.`)] }); }
      if (sub === 'list') return i.reply({ flags: EPH, allowedMentions: none, embeds: [embed('info', `⛔ Server blacklist (action: ${cfg.action})`, Object.entries(cfg.users).map(([id, e]) => `<@${id}> - ${e.reason}`).join('\n').slice(0, 4000) || 'Empty.')] });
      const u = i.options.getUser('user');
      if (sub === 'add') {
        if (perms.isWhitelisted(i.guild, u.id) || u.id === client.user.id) return i.reply({ flags: EPH, content: '🔒 That user is whitelisted/owner.' });
        cfg.users[u.id] = { reason: i.options.getString('reason'), by: i.user.id, ts: Date.now() };
        db.set(i.guild.id, 'blacklist', cfg);
        const m = await i.guild.members.fetch(u.id).catch(() => null);
        if (m) await apply(i.guild, m, `Blacklisted: ${cfg.users[u.id].reason}`);
        return i.reply({ flags: EPH, allowedMentions: none, embeds: [embed('ok', null, `⛔ <@${u.id}> blacklisted${m ? ` and ${cfg.action === 'ban' ? 'banned' : 'kicked'}` : ' (will be removed if they join)'}.`)] });
      }
      delete cfg.users[u.id]; db.set(i.guild.id, 'blacklist', cfg);
      return i.reply({ flags: EPH, allowedMentions: none, embeds: [embed('ok', null, `✅ Removed <@${u.id}> from the blacklist. (Unban them manually if they were banned.)`)] });
    },
  }],
};
