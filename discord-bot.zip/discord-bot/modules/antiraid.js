const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../lib/db');
const { embed, log, isStaff, EPH } = require('../lib/util');
const perms = require('../lib/perms');

const DEF = {
  enabled: false, action: 'kick', timeoutMin: 10,
  joinThreshold: 6, joinWindowSec: 10, lockdownMin: 10, minAccountAgeDays: 0,
  spamLimit: 6, spamWindowSec: 5, mentionLimit: 5, antiInvite: false,
};
const cfgOf = (g) => db.get(g.id, 'antiraid', DEF);
const joins = new Map(), spam = new Map(), lockdown = new Map();

async function act(cfg, member, why) {
  try {
    if (cfg.action === 'ban') await member.ban({ reason: why });
    else if (cfg.action === 'kick') await member.kick(why);
    else await member.timeout(Math.min(cfg.timeoutMin, 40320) * 60000, why);
  } catch { /* missing perms / hierarchy */ }
}
function setLockdown(guildId, minutes) {
  clearTimeout(lockdown.get(guildId));
  if (minutes === null) return lockdown.delete(guildId);
  lockdown.set(guildId, setTimeout(() => lockdown.delete(guildId), minutes * 60000));
}

module.exports = {
  init(client) {
    client.on('guildMemberAdd', async (m) => {
      const cfg = cfgOf(m.guild);
      if (!cfg.enabled || m.user.bot || perms.isWhitelisted(m.guild, m.id)) return;
      if (lockdown.has(m.guild.id)) {
        await m.send('🔒 This server is in raid lockdown. Please try again later.').catch(() => {});
        return act(cfg, m, 'Raid lockdown active');
      }
      if (cfg.minAccountAgeDays > 0 && Date.now() - m.user.createdTimestamp < cfg.minAccountAgeDays * 864e5) {
        log(m.guild, embed('warn', '🚪 Account too new', `${m.user.tag} (${m.id}) - account younger than ${cfg.minAccountAgeDays}d`));
        return act(cfg, m, 'Account too new');
      }
      const now = Date.now();
      const arr = (joins.get(m.guild.id) || []).filter((j) => now - j.ts < cfg.joinWindowSec * 1000);
      arr.push({ id: m.id, ts: now });
      joins.set(m.guild.id, arr);
      if (arr.length >= cfg.joinThreshold) {
        setLockdown(m.guild.id, cfg.lockdownMin);
        joins.delete(m.guild.id);
        log(m.guild, embed('err', '🚨 Raid detected', `${arr.length} joins in ${cfg.joinWindowSec}s. Lockdown for ${cfg.lockdownMin} min. Action: ${cfg.action}.\nUse \`/antiraid lockdown enabled:false\` to end early.`));
        for (const j of arr) { const mem = m.guild.members.cache.get(j.id); if (mem) await act(cfg, mem, 'Raid detected'); }
      }
    });

    client.on('messageCreate', async (msg) => {
      if (!msg.guild || msg.author.bot || !msg.member) return;
      const cfg = cfgOf(msg.guild);
      if (!cfg.enabled || isStaff(msg.member) || perms.isWhitelisted(msg.guild, msg.author.id)) return;

      let why = null;
      if (cfg.antiInvite && /(discord\.gg|discord(app)?\.com\/invite)\/[\w-]+/i.test(msg.content)) why = 'Posting invite links';
      else if (msg.mentions.users.size + msg.mentions.roles.size >= cfg.mentionLimit) why = 'Mass mentions';
      else {
        const key = `${msg.guild.id}:${msg.author.id}`;
        const now = Date.now();
        const arr = (spam.get(key) || []).filter((t) => now - t < cfg.spamWindowSec * 1000);
        arr.push(now); spam.set(key, arr);
        if (arr.length >= cfg.spamLimit) { why = 'Message spam'; spam.delete(key); }
      }
      if (!why) return;

      msg.delete().catch(() => {});
      if (why === 'Message spam') {
        const recent = (await msg.channel.messages.fetch({ limit: 50 }).catch(() => null))?.filter((m) => m.author.id === msg.author.id && Date.now() - m.createdTimestamp < 60000);
        if (recent?.size) msg.channel.bulkDelete(recent, true).catch(() => {});
      }
      msg.member.timeout(cfg.timeoutMin * 60000, `Anti-raid: ${why}`).catch(() => {});
      msg.channel.send(`⚠️ ${msg.author}, ${why.toLowerCase()} isn't allowed here.`).then((m) => setTimeout(() => m.delete().catch(() => {}), 6000)).catch(() => {});
      log(msg.guild, embed('warn', '🛡️ Anti-Raid', `**User:** ${msg.author} (${msg.author.id})\n**Reason:** ${why}\n**Channel:** ${msg.channel}`));
    });
  },

  commands: [{
    data: new SlashCommandBuilder().setName('antiraid').setDescription('Anti-raid and auto-moderation settings')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand((s) => s.setName('status').setDescription('Show settings'))
      .addSubcommand((s) => s.setName('toggle').setDescription('Enable/disable').addBooleanOption((o) => o.setName('enabled').setDescription('On or off').setRequired(true)))
      .addSubcommand((s) => s.setName('joins').setDescription('Raid trigger: X joins within Y seconds')
        .addIntegerOption((o) => o.setName('count').setDescription('Joins').setMinValue(2).setMaxValue(100).setRequired(true))
        .addIntegerOption((o) => o.setName('seconds').setDescription('Window').setMinValue(2).setMaxValue(120).setRequired(true))
        .addIntegerOption((o) => o.setName('lockdown_minutes').setDescription('How long the lockdown lasts').setMinValue(1).setMaxValue(1440)))
      .addSubcommand((s) => s.setName('accountage').setDescription('Block accounts younger than N days (0 = off)').addIntegerOption((o) => o.setName('days').setDescription('Days').setMinValue(0).setMaxValue(365).setRequired(true)))
      .addSubcommand((s) => s.setName('spam').setDescription('X messages within Y seconds = spam')
        .addIntegerOption((o) => o.setName('messages').setDescription('Messages').setMinValue(3).setMaxValue(30).setRequired(true))
        .addIntegerOption((o) => o.setName('seconds').setDescription('Window').setMinValue(2).setMaxValue(30).setRequired(true)))
      .addSubcommand((s) => s.setName('mentions').setDescription('Max mentions per message').addIntegerOption((o) => o.setName('limit').setDescription('Mentions').setMinValue(2).setMaxValue(30).setRequired(true)))
      .addSubcommand((s) => s.setName('invites').setDescription('Block invite links').addBooleanOption((o) => o.setName('enabled').setDescription('On or off').setRequired(true)))
      .addSubcommand((s) => s.setName('action').setDescription('Punishment for raiders')
        .addStringOption((o) => o.setName('type').setDescription('Action').setRequired(true).addChoices({ name: 'kick', value: 'kick' }, { name: 'ban', value: 'ban' }, { name: 'timeout', value: 'timeout' }))
        .addIntegerOption((o) => o.setName('timeout_minutes').setDescription('Timeout length for spam/timeouts').setMinValue(1).setMaxValue(10080)))
      .addSubcommand((s) => s.setName('lockdown').setDescription('Manually start/stop join lockdown (new joins are removed)')
        .addBooleanOption((o) => o.setName('enabled').setDescription('On or off').setRequired(true))
        .addIntegerOption((o) => o.setName('minutes').setDescription('Duration').setMinValue(1).setMaxValue(1440))),
    async execute(i) {
      const cfg = cfgOf(i.guild), sub = i.options.getSubcommand(), o = i.options;
      if (sub === 'toggle') cfg.enabled = o.getBoolean('enabled');
      if (sub === 'joins') { cfg.joinThreshold = o.getInteger('count'); cfg.joinWindowSec = o.getInteger('seconds'); cfg.lockdownMin = o.getInteger('lockdown_minutes') ?? cfg.lockdownMin; }
      if (sub === 'accountage') cfg.minAccountAgeDays = o.getInteger('days');
      if (sub === 'spam') { cfg.spamLimit = o.getInteger('messages'); cfg.spamWindowSec = o.getInteger('seconds'); }
      if (sub === 'mentions') cfg.mentionLimit = o.getInteger('limit');
      if (sub === 'invites') cfg.antiInvite = o.getBoolean('enabled');
      if (sub === 'action') { cfg.action = o.getString('type'); cfg.timeoutMin = o.getInteger('timeout_minutes') ?? cfg.timeoutMin; }
      if (sub === 'lockdown') setLockdown(i.guild.id, o.getBoolean('enabled') ? (o.getInteger('minutes') ?? 10) : null);
      db.save();
      return i.reply({ flags: EPH, embeds: [embed('info', '🛡️ Anti-Raid', [
        `**Status:** ${cfg.enabled ? '✅ Enabled' : '❌ Disabled'} | **Lockdown now:** ${lockdown.has(i.guild.id) ? '🔒 yes' : 'no'}`,
        `**Raid trigger:** ${cfg.joinThreshold} joins / ${cfg.joinWindowSec}s → ${cfg.lockdownMin} min lockdown`,
        `**Min account age:** ${cfg.minAccountAgeDays || 'off'} days`,
        `**Spam:** ${cfg.spamLimit} msgs / ${cfg.spamWindowSec}s | **Mention limit:** ${cfg.mentionLimit} | **Block invites:** ${cfg.antiInvite}`,
        `**Action:** ${cfg.action} | **Timeout length:** ${cfg.timeoutMin} min`,
        'Staff with Manage Messages are exempt from message filters.',
      ].join('\n'))] });
    },
  }],
};
