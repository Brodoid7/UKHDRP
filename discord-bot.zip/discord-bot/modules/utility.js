const { SlashCommandBuilder: S, PermissionFlagsBits: P, ChannelType, EmbedBuilder } = require('discord.js');
const db = require('../lib/db');
const { embed, log, EPH, COLORS } = require('../lib/util');

const warnsOf = (g) => db.get(g.id, 'warns', {});
const NUM = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣'];

const commands = [
  {
    data: new S().setName('ping').setDescription('Bot latency'),
    execute: (i, c) => i.reply({ embeds: [embed('info', '🏓 Pong!', `WebSocket: **${c.ws.ping}ms**`)] }),
  },
  {
    data: new S().setName('help').setDescription('List all commands'),
    execute: (i, c) => i.reply({ flags: EPH, embeds: [embed('info', 'Commands', c.commands.map((x) => `\`/${x.data.name}\` - ${x.data.description}`).join('\n').slice(0, 4000))] }),
  },
  {
    data: new S().setName('avatar').setDescription("Show a user's avatar").addUserOption((o) => o.setName('user').setDescription('User')),
    execute(i) {
      const u = i.options.getUser('user') || i.user;
      return i.reply({ embeds: [embed('info', `${u.username}'s avatar`).setImage(u.displayAvatarURL({ size: 1024 }))] });
    },
  },
  {
    data: new S().setName('userinfo').setDescription('Info about a user').addUserOption((o) => o.setName('user').setDescription('User')),
    async execute(i) {
      const u = i.options.getUser('user') || i.user;
      const m = await i.guild.members.fetch(u.id).catch(() => null);
      const e = embed('info', u.tag).setThumbnail(u.displayAvatarURL()).addFields(
        { name: 'ID', value: u.id, inline: true },
        { name: 'Created', value: `<t:${Math.floor(u.createdTimestamp / 1000)}:R>`, inline: true },
      );
      if (m) e.addFields(
        { name: 'Joined', value: `<t:${Math.floor(m.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: `Roles (${m.roles.cache.size - 1})`, value: m.roles.cache.filter((r) => r.id !== i.guild.id).map((r) => `${r}`).join(' ').slice(0, 1000) || 'none' },
      );
      return i.reply({ embeds: [e] });
    },
  },
  {
    data: new S().setName('serverinfo').setDescription('Info about this server'),
    async execute(i) {
      const g = i.guild;
      return i.reply({ embeds: [embed('info', g.name).setThumbnail(g.iconURL()).addFields(
        { name: 'Owner', value: `<@${g.ownerId}>`, inline: true },
        { name: 'Members', value: `${g.memberCount}`, inline: true },
        { name: 'Channels', value: `${g.channels.cache.size}`, inline: true },
        { name: 'Roles', value: `${g.roles.cache.size}`, inline: true },
        { name: 'Boosts', value: `${g.premiumSubscriptionCount}`, inline: true },
        { name: 'Created', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
      )] });
    },
  },
  {
    data: new S().setName('poll').setDescription('Create a poll')
      .addStringOption((o) => o.setName('question').setDescription('Question').setRequired(true))
      .addStringOption((o) => o.setName('option1').setDescription('Option 1').setRequired(true))
      .addStringOption((o) => o.setName('option2').setDescription('Option 2').setRequired(true))
      .addStringOption((o) => o.setName('option3').setDescription('Option 3'))
      .addStringOption((o) => o.setName('option4').setDescription('Option 4'))
      .addStringOption((o) => o.setName('option5').setDescription('Option 5')),
    async execute(i) {
      const opts = [1, 2, 3, 4, 5].map((n) => i.options.getString(`option${n}`)).filter(Boolean);
      const msg = await i.reply({ embeds: [embed('info', `📊 ${i.options.getString('question')}`, opts.map((o, n) => `${NUM[n]} ${o}`).join('\n')).setFooter({ text: `Poll by ${i.user.username}` })], fetchReply: true });
      for (let n = 0; n < opts.length; n++) await msg.react(NUM[n]);
    },
  },
  {
    data: new S().setName('say').setDescription('Make the bot say something').setDefaultMemberPermissions(P.ManageMessages)
      .addStringOption((o) => o.setName('text').setDescription('Message').setRequired(true).setMaxLength(1900))
      .addChannelOption((o) => o.setName('channel').setDescription('Where').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)),
    async execute(i) {
      const ch = i.options.getChannel('channel') || i.channel;
      await ch.send({ content: i.options.getString('text'), allowedMentions: { parse: [] } });
      return i.reply({ content: '✅ Sent.', flags: EPH });
    },
  },
  {
    data: new S().setName('setlogs').setDescription('Set the channel for bot logs').setDefaultMemberPermissions(P.ManageGuild)
      .addChannelOption((o) => o.setName('channel').setDescription('Log channel').addChannelTypes(ChannelType.GuildText).setRequired(true)),
    execute(i) {
      db.set(i.guild.id, 'logChannel', i.options.getChannel('channel').id);
      return i.reply({ flags: EPH, embeds: [embed('ok', 'Log channel set')] });
    },
  },
  {
    data: new S().setName('purge').setDescription('Bulk delete messages').setDefaultMemberPermissions(P.ManageMessages)
      .addIntegerOption((o) => o.setName('amount').setDescription('1-100').setMinValue(1).setMaxValue(100).setRequired(true))
      .addUserOption((o) => o.setName('user').setDescription('Only this user')),
    async execute(i) {
      await i.deferReply({ flags: EPH });
      let msgs = await i.channel.messages.fetch({ limit: 100 });
      const u = i.options.getUser('user');
      if (u) msgs = msgs.filter((m) => m.author.id === u.id);
      const del = await i.channel.bulkDelete([...msgs.values()].slice(0, i.options.getInteger('amount')), true);
      return i.editReply(`🧹 Deleted **${del.size}** messages (messages older than 14 days can't be bulk deleted).`);
    },
  },
  {
    data: new S().setName('slowmode').setDescription('Set channel slowmode').setDefaultMemberPermissions(P.ManageChannels)
      .addIntegerOption((o) => o.setName('seconds').setDescription('0 to disable').setMinValue(0).setMaxValue(21600).setRequired(true)),
    async execute(i) { await i.channel.setRateLimitPerUser(i.options.getInteger('seconds')); return i.reply(`🐌 Slowmode set to **${i.options.getInteger('seconds')}s**.`); },
  },
  {
    data: new S().setName('lock').setDescription('Lock this channel for @everyone').setDefaultMemberPermissions(P.ManageChannels),
    async execute(i) { await i.channel.permissionOverwrites.edit(i.guild.roles.everyone, { SendMessages: false }); return i.reply('🔒 Channel locked.'); },
  },
  {
    data: new S().setName('unlock').setDescription('Unlock this channel').setDefaultMemberPermissions(P.ManageChannels),
    async execute(i) { await i.channel.permissionOverwrites.edit(i.guild.roles.everyone, { SendMessages: null }); return i.reply('🔓 Channel unlocked.'); },
  },
  {
    data: new S().setName('kick').setDescription('Kick a member').setDefaultMemberPermissions(P.KickMembers)
      .addUserOption((o) => o.setName('user').setDescription('Member').setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Reason')),
    async execute(i) {
      const m = await i.guild.members.fetch(i.options.getUser('user').id).catch(() => null);
      if (!m?.kickable) return i.reply({ flags: EPH, content: "I can't kick that member." });
      const reason = i.options.getString('reason') || 'No reason';
      await m.kick(`${i.user.tag}: ${reason}`);
      log(i.guild, embed('warn', '👢 Kick', `${m.user.tag} by ${i.user}\n${reason}`));
      return i.reply({ embeds: [embed('ok', null, `👢 Kicked **${m.user.tag}** - ${reason}`)] });
    },
  },
  {
    data: new S().setName('ban').setDescription('Ban a user').setDefaultMemberPermissions(P.BanMembers)
      .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Reason'))
      .addIntegerOption((o) => o.setName('delete_days').setDescription('Delete message history (days)').setMinValue(0).setMaxValue(7)),
    async execute(i) {
      const u = i.options.getUser('user'), reason = i.options.getString('reason') || 'No reason';
      const m = await i.guild.members.fetch(u.id).catch(() => null);
      if (m && !m.bannable) return i.reply({ flags: EPH, content: "I can't ban that member." });
      await i.guild.members.ban(u, { reason: `${i.user.tag}: ${reason}`, deleteMessageSeconds: (i.options.getInteger('delete_days') || 0) * 86400 });
      log(i.guild, embed('err', '🔨 Ban', `${u.tag} by ${i.user}\n${reason}`));
      return i.reply({ embeds: [embed('ok', null, `🔨 Banned **${u.tag}** - ${reason}`)] });
    },
  },
  {
    data: new S().setName('unban').setDescription('Unban a user by ID').setDefaultMemberPermissions(P.BanMembers)
      .addStringOption((o) => o.setName('user_id').setDescription('User ID').setRequired(true)),
    async execute(i) {
      const ok = await i.guild.members.unban(i.options.getString('user_id')).then(() => true).catch(() => false);
      return i.reply({ flags: ok ? 0 : EPH, content: ok ? '✅ Unbanned.' : "Couldn't unban - check the ID." });
    },
  },
  {
    data: new S().setName('timeout').setDescription('Timeout a member').setDefaultMemberPermissions(P.ModerateMembers)
      .addUserOption((o) => o.setName('user').setDescription('Member').setRequired(true))
      .addIntegerOption((o) => o.setName('minutes').setDescription('Minutes (0 = remove)').setMinValue(0).setMaxValue(40320).setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Reason')),
    async execute(i) {
      const m = await i.guild.members.fetch(i.options.getUser('user').id).catch(() => null);
      if (!m?.moderatable) return i.reply({ flags: EPH, content: "I can't timeout that member." });
      const min = i.options.getInteger('minutes');
      await m.timeout(min ? min * 60000 : null, i.options.getString('reason') || 'No reason');
      return i.reply({ embeds: [embed('ok', null, min ? `🔇 Timed out **${m.user.tag}** for ${min} min.` : `🔊 Removed timeout from **${m.user.tag}**.`)] });
    },
  },
  {
    data: new S().setName('warn').setDescription('Warn a member').setDefaultMemberPermissions(P.ModerateMembers)
      .addUserOption((o) => o.setName('user').setDescription('Member').setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(true)),
    async execute(i) {
      const u = i.options.getUser('user'), w = warnsOf(i.guild);
      (w[u.id] ||= []).push({ mod: i.user.id, reason: i.options.getString('reason'), ts: Date.now() });
      db.save();
      u.send({ embeds: [embed('warn', `⚠️ Warning in ${i.guild.name}`, i.options.getString('reason'))] }).catch(() => {});
      log(i.guild, embed('warn', '⚠️ Warn', `${u.tag} by ${i.user}\n${i.options.getString('reason')}`));
      return i.reply({ embeds: [embed('ok', null, `⚠️ Warned **${u.tag}** (total: ${w[u.id].length})`)] });
    },
  },
  {
    data: new S().setName('warnings').setDescription("View a member's warnings").setDefaultMemberPermissions(P.ModerateMembers)
      .addUserOption((o) => o.setName('user').setDescription('Member').setRequired(true))
      .addBooleanOption((o) => o.setName('clear').setDescription('Clear all their warnings')),
    execute(i) {
      const u = i.options.getUser('user'), w = warnsOf(i.guild);
      if (i.options.getBoolean('clear')) { delete w[u.id]; db.save(); return i.reply({ flags: EPH, content: '🧽 Cleared.' }); }
      const body = (w[u.id] || []).map((x, n) => `**${n + 1}.** ${x.reason} - <@${x.mod}> <t:${Math.floor(x.ts / 1000)}:R>`).join('\n') || 'No warnings.';
      return i.reply({ flags: EPH, embeds: [embed('info', `Warnings: ${u.tag}`, body.slice(0, 4000))] });
    },
  },
];

module.exports = { commands };
