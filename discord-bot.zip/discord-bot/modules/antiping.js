const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../lib/db');
const { embed, EPH, isStaff, log } = require('../lib/util');
const perms = require('../lib/perms');

const DEF = { users: [], roles: [], bypassRoles: [], timeoutAfter: 3, timeoutMin: 5, strikes: {} };
const cfgOf = (g) => db.get(g.id, 'antiping', DEF);

module.exports = {
  init(client) {
    client.on('messageCreate', async (msg) => {
      if (!msg.guild || msg.author.bot || !msg.member) return;
      const cfg = cfgOf(msg.guild);
      if (!cfg.users.length && !cfg.roles.length) return;
      if (isStaff(msg.member) || perms.isWhitelisted(msg.guild, msg.author.id) || cfg.users.includes(msg.author.id) || msg.member.roles.cache.some((r) => cfg.bypassRoles.includes(r.id))) return;

      const hit = msg.mentions.users.some((u) => cfg.users.includes(u.id)) || msg.mentions.roles.some((r) => cfg.roles.includes(r.id));
      if (!hit) return;

      msg.delete().catch(() => {});
      const n = (cfg.strikes[msg.author.id] = (cfg.strikes[msg.author.id] || 0) + 1);
      db.save();
      let note = `⚠️ ${msg.author}, please don't ping protected members/roles. (strike ${n}/${cfg.timeoutAfter})`;
      if (n >= cfg.timeoutAfter) {
        cfg.strikes[msg.author.id] = 0;
        await msg.member.timeout(cfg.timeoutMin * 60000, 'Anti-ping').catch(() => {});
        note = `🔇 ${msg.author} was timed out for ${cfg.timeoutMin} min for repeated pings.`;
      }
      msg.channel.send(note).then((m) => setTimeout(() => m.delete().catch(() => {}), 7000)).catch(() => {});
      log(msg.guild, embed('warn', '🔕 Anti-Ping', `${msg.author} pinged a protected target in ${msg.channel}`));
    });
  },
  commands: [{
    data: new SlashCommandBuilder().setName('antiping').setDescription('Protect people/roles from being pinged')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
      .addSubcommand((s) => s.setName('user').setDescription('Protect or unprotect a user')
        .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))
        .addBooleanOption((o) => o.setName('protect').setDescription('true = protect, false = remove').setRequired(true)))
      .addSubcommand((s) => s.setName('role').setDescription('Protect or unprotect a role')
        .addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true))
        .addBooleanOption((o) => o.setName('protect').setDescription('true = protect, false = remove').setRequired(true)))
      .addSubcommand((s) => s.setName('bypass').setDescription('Roles allowed to ping protected targets')
        .addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true))
        .addBooleanOption((o) => o.setName('allow').setDescription('true = add, false = remove').setRequired(true)))
      .addSubcommand((s) => s.setName('punish').setDescription('Timeout after N strikes')
        .addIntegerOption((o) => o.setName('strikes').setDescription('Strikes').setMinValue(1).setMaxValue(20).setRequired(true))
        .addIntegerOption((o) => o.setName('minutes').setDescription('Timeout minutes').setMinValue(1).setMaxValue(10080).setRequired(true)))
      .addSubcommand((s) => s.setName('list').setDescription('Show protected targets')),
    async execute(i) {
      const cfg = cfgOf(i.guild), sub = i.options.getSubcommand();
      const toggle = (arr, id, on) => { const a = arr.filter((x) => x !== id); if (on) a.push(id); return a; };
      if (sub === 'user') cfg.users = toggle(cfg.users, i.options.getUser('user').id, i.options.getBoolean('protect'));
      if (sub === 'role') cfg.roles = toggle(cfg.roles, i.options.getRole('role').id, i.options.getBoolean('protect'));
      if (sub === 'bypass') cfg.bypassRoles = toggle(cfg.bypassRoles, i.options.getRole('role').id, i.options.getBoolean('allow'));
      if (sub === 'punish') { cfg.timeoutAfter = i.options.getInteger('strikes'); cfg.timeoutMin = i.options.getInteger('minutes'); }
      db.save();
      return i.reply({ flags: EPH, embeds: [embed('info', '🔕 Anti-Ping', [
        `**Protected users:** ${cfg.users.map((x) => `<@${x}>`).join(', ') || 'none'}`,
        `**Protected roles:** ${cfg.roles.map((x) => `<@&${x}>`).join(', ') || 'none'}`,
        `**Bypass roles:** ${cfg.bypassRoles.map((x) => `<@&${x}>`).join(', ') || 'none'}`,
        `**Punishment:** timeout ${cfg.timeoutMin}m after ${cfg.timeoutAfter} strikes`,
      ].join('\n'))] });
    },
  }],
};
