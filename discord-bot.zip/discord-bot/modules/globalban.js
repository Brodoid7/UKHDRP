const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../lib/db');
const perms = require('../lib/perms');
const { embed, log, EPH } = require('../lib/util');

const gbans = () => db.get('global', 'gbans', {});
const cfgOf = (g) => db.get(g.id, 'gbanCfg', { enforce: true });
const TAG = '[GBAN] ';

async function enforceIn(guild, id, entry) {
  if (!cfgOf(guild).enforce || id === guild.ownerId) return 'skipped';
  try {
    await guild.members.ban(id, { reason: `${TAG}${entry.reason}`.slice(0, 500) });
    log(guild, embed('err', '🌐 Global ban enforced', `<@${id}> (${id})\n**Reason:** ${entry.reason}${entry.proof ? `\n**Proof:** ${entry.proof}` : ''}`));
    return 'banned';
  } catch { return 'failed'; }
}

async function banEverywhere(client, id, entry) {
  const res = { banned: 0, failed: 0, skipped: 0 };
  for (const g of client.guilds.cache.values()) {
    if (!(await g.members.fetch(id).catch(() => null))) continue; // join listener covers future joins
    res[await enforceIn(g, id, entry)]++;
  }
  return res;
}

module.exports = {
  init(client) {
    client.on('guildMemberAdd', async (m) => {
      const entry = gbans()[m.id];
      if (entry && !perms.isGlobalWhitelisted(m.id)) enforceIn(m.guild, m.id, entry);
    });
    // Joining a new server: sweep its member list
    client.on('guildCreate', async (g) => {
      const members = await g.members.fetch().catch(() => null);
      if (!members) return;
      for (const [id] of members) if (gbans()[id] && !perms.isGlobalWhitelisted(id)) await enforceIn(g, id, gbans()[id]);
    });
  },
  commands: [{
    data: new SlashCommandBuilder().setName('gban').setDescription('Global ban system (bans across every server the bot is in)')
      .addSubcommand((s) => s.setName('add').setDescription('Global ban a user (bot admin+)')
        .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))
        .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(true).setMaxLength(300))
        .addStringOption((o) => o.setName('proof').setDescription('Link to evidence').setMaxLength(300)))
      .addSubcommand((s) => s.setName('remove').setDescription('Lift a global ban (bot admin+)').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
      .addSubcommand((s) => s.setName('check').setDescription('Check if a user is globally banned (bot staff or Ban Members)').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
      .addSubcommand((s) => s.setName('list').setDescription('List global bans (bot staff)'))
      .addSubcommand((s) => s.setName('sync').setDescription('Re-scan every server for globally banned members (bot admin+)'))
      .addSubcommand((s) => s.setName('config').setDescription('Enforce global bans in THIS server (Manage Server)').addBooleanOption((o) => o.setName('enforce').setDescription('true = enforce, false = ignore').setRequired(true))),
    async execute(i, client) {
      const sub = i.options.getSubcommand(), list = gbans();
      if (sub === 'config') {
        if (!i.memberPermissions.has(PermissionFlagsBits.ManageGuild)) return i.reply({ flags: EPH, content: '🔒 Needs Manage Server.' });
        cfgOf(i.guild).enforce = i.options.getBoolean('enforce'); db.save();
        return i.reply({ flags: EPH, embeds: [embed('ok', 'Global bans', cfgOf(i.guild).enforce ? '✅ Enforced in this server.' : '⏸️ Not enforced in this server.')] });
      }
      if (sub === 'check') {
        if (perms.rankOf(i.user.id) < 1 && !i.memberPermissions.has(PermissionFlagsBits.BanMembers)) return i.reply({ flags: EPH, content: '🔒 Bot staff or Ban Members required.' });
        const u = i.options.getUser('user'), e = list[u.id];
        return i.reply({ flags: EPH, allowedMentions: { parse: [] }, embeds: [e
          ? embed('err', '🌐 Globally banned', `**User:** ${u.tag} (${u.id})\n**Reason:** ${e.reason}\n**Proof:** ${e.proof || 'none'}\n**By:** <@${e.by}> • <t:${Math.floor(e.ts / 1000)}:R>`)
          : embed('ok', 'Clean', `${u.tag} is not globally banned.`)] });
      }
      if (sub === 'list') {
        if (perms.denyUnless(i, 'mod')) return;
        const rows = Object.entries(list).slice(-30).map(([id, e]) => `<@${id}> (${id}) - ${e.reason.slice(0, 60)}`).join('\n') || 'None.';
        return i.reply({ flags: EPH, allowedMentions: { parse: [] }, embeds: [embed('info', `🌐 Global bans (${Object.keys(list).length})`, rows.slice(0, 4000))] });
      }
      if (perms.denyUnless(i, 'admin')) return;
      if (sub === 'sync') {
        await i.deferReply({ flags: EPH });
        let n = 0;
        for (const [id, e] of Object.entries(list)) { if (perms.isGlobalWhitelisted(id)) continue; const r = await banEverywhere(client, id, e); n += r.banned; }
        return i.editReply(`🔄 Sync done - **${n}** ban(s) applied.`);
      }
      const u = i.options.getUser('user');
      if (sub === 'add') {
        if (u.id === client.user.id || u.id === i.user.id) return i.reply({ flags: EPH, content: 'Not that one.' });
        if (perms.rankOf(u.id) >= 1 || perms.isGlobalWhitelisted(u.id)) return i.reply({ flags: EPH, content: '🔒 That user is bot staff / globally whitelisted.' });
        await i.deferReply({ flags: EPH });
        const entry = { reason: i.options.getString('reason'), proof: i.options.getString('proof') || null, by: i.user.id, ts: Date.now() };
        list[u.id] = entry; db.save();
        const r = await banEverywhere(client, u.id, entry);
        return i.editReply({ embeds: [embed('ok', '🌐 Global ban added', `**${u.tag}** (${u.id})\nBanned now in **${r.banned}** server(s) • failed ${r.failed} • skipped ${r.skipped}\nThey'll be banned automatically wherever they join.`)] });
      }
      // remove
      if (!list[u.id]) return i.reply({ flags: EPH, content: 'That user isn\'t globally banned.' });
      await i.deferReply({ flags: EPH });
      delete list[u.id]; db.save();
      let lifted = 0;
      for (const g of client.guilds.cache.values()) {
        const b = await g.bans.fetch(u.id).catch(() => null);
        if (b?.reason?.startsWith(TAG) && (await g.members.unban(u.id, 'Global ban lifted').then(() => true).catch(() => false))) lifted++;
      }
      return i.editReply(`✅ Global ban lifted. Unbanned in **${lifted}** server(s).`);
    },
  }],
};
