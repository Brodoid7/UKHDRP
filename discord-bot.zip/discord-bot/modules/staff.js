const { SlashCommandBuilder } = require('discord.js');
const db = require('../lib/db');
const perms = require('../lib/perms');
const { embed, EPH } = require('../lib/util');

const ICON = { mod: '🛡️', admin: '⚙️', owner: '👑' };
// owners manage everyone; admins can only manage mods
const canManage = (my, rank) => my === perms.RANKS.owner || (my === perms.RANKS.admin && rank === 'mod');

module.exports = {
  init(client) {
    // The Discord application owner (or team members) always count as bot owners.
    client.once('clientReady', async () => {
      const app = await client.application.fetch().catch(() => null);
      const o = app?.owner;
      if (!o) return;
      perms.setOwners(o.members ? [...o.members.keys()] : [o.id]);
    });
  },
  commands: [
    {
      data: new SlashCommandBuilder().setName('staff').setDescription('Bot staff system (global)')
        .addSubcommand((s) => s.setName('add').setDescription('Add bot staff')
          .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))
          .addStringOption((o) => o.setName('rank').setDescription('Rank').setRequired(true).addChoices({ name: 'mod - can flag, view lists', value: 'mod' }, { name: 'admin - can gban + blacklist', value: 'admin' })))
        .addSubcommand((s) => s.setName('remove').setDescription('Remove bot staff').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
        .addSubcommand((s) => s.setName('whitelist').setDescription('Globally whitelist/unwhitelist a user (owners only)')
          .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))
          .addBooleanOption((o) => o.setName('enabled').setDescription('true = whitelist, false = remove').setRequired(true)))
        .addSubcommand((s) => s.setName('list').setDescription('Show bot staff and global whitelist')),
      async execute(i) {
        const sub = i.options.getSubcommand(), my = perms.rankOf(i.user.id), staff = perms.staff();
        if (sub === 'list') {
          if (perms.denyUnless(i, 'mod')) return;
          const rows = [...perms.owners().map((id) => `${ICON.owner} <@${id}> - owner`), ...Object.entries(staff).map(([id, s]) => `${ICON[s.rank]} <@${id}> - ${s.rank}`)];
          return i.reply({ flags: EPH, allowedMentions: { parse: [] }, embeds: [embed('info', 'Bot staff', [
            rows.join('\n') || 'none',
            '', `**Global whitelist:** ${perms.globalWhitelist().map((x) => `<@${x}>`).join(', ') || 'none'}`,
          ].join('\n'))] });
        }
        if (sub === 'whitelist') {
          if (perms.denyUnless(i, 'owner')) return;
          const id = i.options.getUser('user').id, wl = perms.globalWhitelist().filter((x) => x !== id);
          if (i.options.getBoolean('enabled')) wl.push(id);
          db.set('global', 'whitelist', wl);
          return i.reply({ flags: EPH, embeds: [embed('ok', null, `${i.options.getBoolean('enabled') ? '✅ Globally whitelisted' : '🗑️ Removed from global whitelist:'} <@${id}>`)], allowedMentions: { parse: [] } });
        }
        const u = i.options.getUser('user');
        if (sub === 'add') {
          const rank = i.options.getString('rank');
          if (u.bot) return i.reply({ flags: EPH, content: 'Bots can\'t be staff.' });
          if (!canManage(my, rank)) return i.reply({ flags: EPH, content: '🔒 Owners can add anyone; admins can only add mods.' });
          if (perms.owners().includes(u.id)) return i.reply({ flags: EPH, content: 'They\'re already an owner.' });
          const existing = staff[u.id]?.rank;
          if (existing && !canManage(my, existing)) return i.reply({ flags: EPH, content: 'You can\'t change that user\'s rank.' });
          staff[u.id] = { rank, by: i.user.id, ts: Date.now() }; db.save();
          return i.reply({ flags: EPH, embeds: [embed('ok', null, `${ICON[rank]} <@${u.id}> is now bot **${rank}**.`)], allowedMentions: { parse: [] } });
        }
        // remove
        const t = staff[u.id];
        if (!t) return i.reply({ flags: EPH, content: 'That user isn\'t bot staff.' });
        if (!canManage(my, t.rank)) return i.reply({ flags: EPH, content: '🔒 You can\'t remove that rank.' });
        delete staff[u.id]; db.save();
        return i.reply({ flags: EPH, embeds: [embed('ok', null, `Removed <@${u.id}> from bot staff.`)], allowedMentions: { parse: [] } });
      },
    },
    {
      data: new SlashCommandBuilder().setName('whitelist').setDescription('Server whitelist: bypasses anti-nuke, anti-raid, anti-ping & filters (server owner only)')
        .addSubcommand((s) => s.setName('add').setDescription('Whitelist a user').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
        .addSubcommand((s) => s.setName('remove').setDescription('Remove from whitelist').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
        .addSubcommand((s) => s.setName('list').setDescription('Show whitelist')),
      async execute(i) {
        const sub = i.options.getSubcommand();
        const owner = i.user.id === i.guild.ownerId || perms.rankOf(i.user.id) >= perms.RANKS.owner;
        const wl = perms.guildWhitelist(i.guild);
        if (sub === 'list') return i.reply({ flags: EPH, allowedMentions: { parse: [] }, embeds: [embed('info', '✅ Server whitelist', wl.map((x) => `<@${x}>`).join('\n') || 'Empty.')] });
        if (!owner) return i.reply({ flags: EPH, content: '🔒 Only the server owner can edit the whitelist.' });
        const id = i.options.getUser('user').id;
        const next = wl.filter((x) => x !== id);
        if (sub === 'add') next.push(id);
        db.set(i.guild.id, 'whitelist', next);
        return i.reply({ flags: EPH, allowedMentions: { parse: [] }, embeds: [embed('ok', null, sub === 'add' ? `✅ Whitelisted <@${id}>.` : `🗑️ Removed <@${id}>.`)] });
      },
    },
  ],
};
