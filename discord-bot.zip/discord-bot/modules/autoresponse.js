const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../lib/db');
const { embed, EPH } = require('../lib/util');

const list = (g) => db.get(g.id, 'autoresponses', []);
const cooldown = new Map();
const fill = (t, msg) => t.replaceAll('{user}', `${msg.author}`).replaceAll('{username}', msg.author.username)
  .replaceAll('{server}', msg.guild.name).replaceAll('{channel}', `${msg.channel}`).replaceAll('{members}', msg.guild.memberCount);

module.exports = {
  init(client) {
    client.on('messageCreate', async (msg) => {
      if (!msg.guild || msg.author.bot || !msg.content) return;
      const text = msg.content.toLowerCase().trim();
      const hit = list(msg.guild).find((r) => r.match === 'exact' ? text === r.trigger : r.match === 'startswith' ? text.startsWith(r.trigger) : text.includes(r.trigger));
      if (!hit) return;
      const key = `${msg.channel.id}:${hit.id}`;
      if (Date.now() - (cooldown.get(key) || 0) < 3000) return;
      cooldown.set(key, Date.now());
      msg.reply({ content: fill(hit.response, msg), allowedMentions: { repliedUser: false, parse: [] } }).catch(() => {});
    });
  },
  commands: [{
    data: new SlashCommandBuilder().setName('autoresponse').setDescription('Custom auto-replies')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
      .addSubcommand((s) => s.setName('add').setDescription('Add an auto-response')
        .addStringOption((o) => o.setName('trigger').setDescription('Text to look for').setRequired(true).setMaxLength(100))
        .addStringOption((o) => o.setName('response').setDescription('Reply. Variables: {user} {username} {server} {channel} {members}').setRequired(true).setMaxLength(1900))
        .addStringOption((o) => o.setName('match').setDescription('How to match (default: contains)').addChoices({ name: 'contains', value: 'contains' }, { name: 'exact', value: 'exact' }, { name: 'starts with', value: 'startswith' })))
      .addSubcommand((s) => s.setName('remove').setDescription('Remove one').addIntegerOption((o) => o.setName('id').setDescription('ID from /autoresponse list').setRequired(true)))
      .addSubcommand((s) => s.setName('list').setDescription('List all')),
    async execute(i) {
      const arr = list(i.guild), sub = i.options.getSubcommand();
      if (sub === 'add') {
        const id = (arr.at(-1)?.id ?? 0) + 1;
        arr.push({ id, trigger: i.options.getString('trigger').toLowerCase().trim(), response: i.options.getString('response'), match: i.options.getString('match') || 'contains' });
        db.save();
        return i.reply({ flags: EPH, embeds: [embed('ok', 'Added', `ID **${id}** created.`)] });
      }
      if (sub === 'remove') {
        const idx = arr.findIndex((r) => r.id === i.options.getInteger('id'));
        if (idx < 0) return i.reply({ flags: EPH, content: 'No auto-response with that ID.' });
        arr.splice(idx, 1); db.save();
        return i.reply({ flags: EPH, embeds: [embed('ok', 'Removed')] });
      }
      const body = arr.map((r) => `**${r.id}.** \`${r.trigger}\` (${r.match}) → ${r.response.slice(0, 60)}`).join('\n') || 'None yet.';
      return i.reply({ flags: EPH, embeds: [embed('info', 'Auto-responses', body.slice(0, 4000))] });
    },
  }],
};
