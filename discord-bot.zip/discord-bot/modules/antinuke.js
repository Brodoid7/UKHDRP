const { SlashCommandBuilder, PermissionFlagsBits, AuditLogEvent, PermissionsBitField } = require('discord.js');
const db = require('../lib/db');
const { embed, log, EPH } = require('../lib/util');
const perms = require('../lib/perms');

const DEF = {
  enabled: false, whitelist: [], windowSec: 10, punishment: 'ban', restore: true, antiBot: true, antiAdminGrant: true,
  limits: { channelDelete: 2, channelCreate: 4, roleDelete: 2, roleCreate: 4, ban: 3, kick: 3, webhook: 2 },
};
const hits = new Map();
const cfgOf = (g) => db.get(g.id, 'antinuke', DEF);

// Looks up who did it, counts actions in the time window, punishes at the limit.
// Returns null if exempt/disabled, otherwise { uid, tripped }.
async function check(client, guild, type, action) {
  const cfg = cfgOf(guild);
  if (!cfg.enabled) return null;
  const logs = await guild.fetchAuditLogs({ type, limit: 1 }).catch(() => null);
  const entry = logs?.entries.first();
  if (!entry?.executor || Date.now() - entry.createdTimestamp > 5000) return null;
  const uid = entry.executor.id;
  if (uid === client.user.id || perms.isWhitelisted(guild, uid) || cfg.whitelist.includes(uid)) return null;

  const key = `${guild.id}:${uid}:${action}`;
  const now = Date.now();
  const arr = (hits.get(key) || []).filter((t) => now - t < cfg.windowSec * 1000);
  arr.push(now);
  hits.set(key, arr);
  const limit = cfg.limits[action] ?? 3;
  if (arr.length < limit) return { uid, tripped: false };
  hits.delete(key);
  await punish(guild, uid, `Anti-nuke: ${action} x${arr.length} in ${cfg.windowSec}s`);
  return { uid, tripped: true };
}

async function punish(guild, uid, reason) {
  const cfg = cfgOf(guild);
  let result = 'success';
  try {
    if (cfg.punishment === 'ban') await guild.members.ban(uid, { reason });
    else {
      const m = await guild.members.fetch(uid);
      if (cfg.punishment === 'kick') await m.kick(reason);
      else await m.roles.set([], reason); // strip
    }
  } catch (e) { result = `FAILED (${e.message}) - my role must be above theirs`; }
  log(guild, embed('err', '🚨 Anti-Nuke Triggered', `**User:** <@${uid}> (${uid})\n**Reason:** ${reason}\n**Action:** ${cfg.punishment} - ${result}`));
}

module.exports = {
  init(client) {
    client.on('channelDelete', async (ch) => {
      if (!ch.guild) return;
      const r = await check(client, ch.guild, AuditLogEvent.ChannelDelete, 'channelDelete');
      if (r && cfgOf(ch.guild).restore) await ch.clone({ reason: 'Anti-nuke restore' }).catch(() => {});
    });
    client.on('channelCreate', async (ch) => {
      const r = await check(client, ch.guild, AuditLogEvent.ChannelCreate, 'channelCreate');
      if (r?.tripped) ch.delete('Anti-nuke').catch(() => {});
    });
    client.on('roleDelete', async (role) => {
      const r = await check(client, role.guild, AuditLogEvent.RoleDelete, 'roleDelete');
      if (r && cfgOf(role.guild).restore)
        await role.guild.roles.create({ name: role.name, color: role.color, hoist: role.hoist, permissions: role.permissions, mentionable: role.mentionable, reason: 'Anti-nuke restore' }).catch(() => {});
    });
    client.on('roleCreate', async (role) => {
      const r = await check(client, role.guild, AuditLogEvent.RoleCreate, 'roleCreate');
      if (r?.tripped) role.delete('Anti-nuke').catch(() => {});
    });
    client.on('guildBanAdd', (ban) => check(client, ban.guild, AuditLogEvent.MemberBanAdd, 'ban'));
    client.on('guildMemberRemove', (m) => check(client, m.guild, AuditLogEvent.MemberKick, 'kick'));
    client.on('webhooksUpdate', async (ch) => {
      const r = await check(client, ch.guild, AuditLogEvent.WebhookCreate, 'webhook');
      if (r?.tripped) (await ch.fetchWebhooks().catch(() => null))?.forEach((w) => w.delete('Anti-nuke').catch(() => {}));
    });

    // Unauthorised bot added -> kick the bot + punish whoever added it
    client.on('guildMemberAdd', async (m) => {
      const cfg = cfgOf(m.guild);
      if (!cfg.enabled || !cfg.antiBot || !m.user.bot) return;
      const logs = await m.guild.fetchAuditLogs({ type: AuditLogEvent.BotAdd, limit: 1 }).catch(() => null);
      const e = logs?.entries.first();
      if (!e?.executor || e.target?.id !== m.id) return;
      const uid = e.executor.id;
      if (perms.isWhitelisted(m.guild, uid) || cfg.whitelist.includes(uid) || uid === client.user.id) return;
      await m.kick('Anti-nuke: unauthorised bot').catch(() => {});
      await punish(m.guild, uid, `Added unauthorised bot ${m.user.tag}`);
    });

    // Someone grants Administrator to a role -> revert + punish
    client.on('roleUpdate', async (oldR, newR) => {
      const cfg = cfgOf(newR.guild);
      if (!cfg.enabled || !cfg.antiAdminGrant) return;
      const had = oldR.permissions.has(PermissionsBitField.Flags.Administrator);
      const has = newR.permissions.has(PermissionsBitField.Flags.Administrator);
      if (had || !has) return;
      const logs = await newR.guild.fetchAuditLogs({ type: AuditLogEvent.RoleUpdate, limit: 1 }).catch(() => null);
      const uid = logs?.entries.first()?.executor?.id;
      if (!uid || uid === client.user.id || perms.isWhitelisted(newR.guild, uid) || cfg.whitelist.includes(uid)) return;
      await newR.setPermissions(oldR.permissions, 'Anti-nuke revert').catch(() => {});
      await punish(newR.guild, uid, `Granted Administrator to @${newR.name}`);
    });
  },

  commands: [{
    data: new SlashCommandBuilder().setName('antinuke').setDescription('Anti-nuke protection (server owner only)')
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addSubcommand((s) => s.setName('status').setDescription('Show settings'))
      .addSubcommand((s) => s.setName('toggle').setDescription('Enable/disable').addBooleanOption((o) => o.setName('enabled').setDescription('On or off').setRequired(true)))
      .addSubcommand((s) => s.setName('whitelist').setDescription('Trust a user (immune to anti-nuke)')
        .addStringOption((o) => o.setName('action').setDescription('add/remove').setRequired(true).addChoices({ name: 'add', value: 'add' }, { name: 'remove', value: 'remove' }))
        .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
      .addSubcommand((s) => s.setName('punishment').setDescription('What to do to nukers')
        .addStringOption((o) => o.setName('type').setDescription('Punishment').setRequired(true).addChoices({ name: 'ban', value: 'ban' }, { name: 'kick', value: 'kick' }, { name: 'strip all roles', value: 'strip' })))
      .addSubcommand((s) => s.setName('limit').setDescription('Set how many actions in the window trigger punishment')
        .addStringOption((o) => o.setName('action').setDescription('Which action').setRequired(true).addChoices(...Object.keys(DEF.limits).map((k) => ({ name: k, value: k }))))
        .addIntegerOption((o) => o.setName('count').setDescription('Actions allowed before punishment (1-20)').setMinValue(1).setMaxValue(20).setRequired(true)))
      .addSubcommand((s) => s.setName('window').setDescription('Time window in seconds').addIntegerOption((o) => o.setName('seconds').setDescription('3-120').setMinValue(3).setMaxValue(120).setRequired(true)))
      .addSubcommand((s) => s.setName('options').setDescription('Extra toggles')
        .addBooleanOption((o) => o.setName('restore').setDescription('Re-create deleted channels/roles'))
        .addBooleanOption((o) => o.setName('antibot').setDescription('Kick unauthorised bots'))
        .addBooleanOption((o) => o.setName('antiadmin').setDescription('Revert Administrator grants'))),
    async execute(i) {
      if (i.user.id !== i.guild.ownerId) return i.reply({ content: '🔒 Only the server owner can change anti-nuke settings.', flags: EPH });
      const cfg = cfgOf(i.guild);
      const sub = i.options.getSubcommand();
      if (sub === 'toggle') cfg.enabled = i.options.getBoolean('enabled');
      if (sub === 'whitelist') {
        const u = i.options.getUser('user').id;
        cfg.whitelist = cfg.whitelist.filter((x) => x !== u);
        if (i.options.getString('action') === 'add') cfg.whitelist.push(u);
      }
      if (sub === 'punishment') cfg.punishment = i.options.getString('type');
      if (sub === 'limit') cfg.limits[i.options.getString('action')] = i.options.getInteger('count');
      if (sub === 'window') cfg.windowSec = i.options.getInteger('seconds');
      if (sub === 'options') {
        const r = i.options.getBoolean('restore'), b = i.options.getBoolean('antibot'), a = i.options.getBoolean('antiadmin');
        if (r !== null) cfg.restore = r; if (b !== null) cfg.antiBot = b; if (a !== null) cfg.antiAdminGrant = a;
      }
      db.save();
      const lim = Object.entries(cfg.limits).map(([k, v]) => `\`${k}\`: ${v}`).join(' • ');
      return i.reply({ flags: EPH, embeds: [embed('info', '🛡️ Anti-Nuke', [
        `**Status:** ${cfg.enabled ? '✅ Enabled' : '❌ Disabled'}`,
        `**Punishment:** ${cfg.punishment} | **Window:** ${cfg.windowSec}s`,
        `**Restore deleted:** ${cfg.restore} | **Anti-bot:** ${cfg.antiBot} | **Anti-admin-grant:** ${cfg.antiAdminGrant}`,
        `**Limits:** ${lim}`,
        `**Whitelist:** ${cfg.whitelist.map((x) => `<@${x}>`).join(', ') || 'none'}`,
        '',
        '*Needs View Audit Log, Ban, Kick, Manage Roles/Channels/Webhooks. Keep my role at the top of the role list.*',
      ].join('\n'))] });
    },
  }],
};
