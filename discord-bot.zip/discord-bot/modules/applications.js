const {
  SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder, ChannelType,
} = require('discord.js');
const db = require('../lib/db');
const { embed, EPH } = require('../lib/util');
const perms = require('../lib/perms');

// apps[name] = { questions: [], reviewChannel, acceptRole, open }  - no cap on questions
const appsOf = (g) => db.get(g.id, 'applications', {});
const active = new Set(); // user IDs mid-application (modmail ignores their DMs)
const key = (s) => s.toLowerCase().trim();

async function runApplication(user, guild, name, app) {
  const dm = await user.createDM();
  active.add(user.id);
  const answers = [];
  let ok = false;
  try {
    await dm.send({ embeds: [embed('info', `📝 Application: ${name}`, `**${app.questions.length}** questions. Answer each one in a message (attachments are fine).\nType \`cancel\` at any time to stop. You have 10 minutes per question.`)] });
    for (let n = 0; n < app.questions.length; n++) {
      await dm.send(`**Question ${n + 1}/${app.questions.length}**\n${app.questions[n]}`);
      const got = await dm.awaitMessages({ filter: (m) => m.author.id === user.id, max: 1, time: 600000, errors: ['time'] });
      const m = got.first();
      if (m.content.toLowerCase() === 'cancel') { await dm.send('❌ Application cancelled.'); return; }
      answers.push([m.content, ...m.attachments.map((a) => a.url)].filter(Boolean).join('\n') || '(empty)');
    }
    ok = true;
  } catch { await dm.send('⌛ Timed out - application cancelled. Run `/apply` to start again.').catch(() => {}); }
  finally { active.delete(user.id); }
  if (!ok) return;

  await dm.send({ embeds: [embed('ok', '✅ Submitted!', 'Staff will review your application soon.')] });
  const ch = guild.channels.cache.get(app.reviewChannel);
  if (!ch) return;
  const full = app.questions.map((q, n) => `Q${n + 1}: ${q}\nA: ${answers[n]}\n`).join('\n');
  const e = embed('info', `📨 New application: ${name}`, `**Applicant:** ${user} (${user.id})`).setThumbnail(user.displayAvatarURL());
  app.questions.slice(0, 10).forEach((q, n) => e.addFields({ name: `${n + 1}. ${q}`.slice(0, 256), value: answers[n].slice(0, 1000) }));
  if (app.questions.length > 10) e.setFooter({ text: `Showing 10 of ${app.questions.length} - full answers attached` });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`app:accept:${user.id}:${name}`.slice(0, 100)).setLabel('Accept').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`app:deny:${user.id}:${name}`.slice(0, 100)).setLabel('Deny').setStyle(ButtonStyle.Danger),
  );
  await ch.send({ embeds: [e], components: [row], files: [new AttachmentBuilder(Buffer.from(full), { name: `application-${user.username}.txt` })] });
}

const adminCmd = new SlashCommandBuilder().setName('appadmin').setDescription('Manage applications')
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
  .addSubcommand((s) => s.setName('create').setDescription('Create an application').addStringOption((o) => o.setName('name').setDescription('e.g. staff').setRequired(true).setMaxLength(30)))
  .addSubcommand((s) => s.setName('delete').setDescription('Delete an application').addStringOption((o) => o.setName('name').setDescription('Name').setRequired(true).setAutocomplete(true)))
  .addSubcommand((s) => s.setName('addquestion').setDescription('Add a question (no limit)')
    .addStringOption((o) => o.setName('name').setDescription('Application').setRequired(true).setAutocomplete(true))
    .addStringOption((o) => o.setName('question').setDescription('Question text').setRequired(true).setMaxLength(1500)))
  .addSubcommand((s) => s.setName('removequestion').setDescription('Remove a question by number')
    .addStringOption((o) => o.setName('name').setDescription('Application').setRequired(true).setAutocomplete(true))
    .addIntegerOption((o) => o.setName('number').setDescription('Question #').setMinValue(1).setRequired(true)))
  .addSubcommand((s) => s.setName('review').setDescription('Where submissions go')
    .addStringOption((o) => o.setName('name').setDescription('Application').setRequired(true).setAutocomplete(true))
    .addChannelOption((o) => o.setName('channel').setDescription('Channel').addChannelTypes(ChannelType.GuildText).setRequired(true)))
  .addSubcommand((s) => s.setName('role').setDescription('Role given on accept')
    .addStringOption((o) => o.setName('name').setDescription('Application').setRequired(true).setAutocomplete(true))
    .addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true)))
  .addSubcommand((s) => s.setName('toggle').setDescription('Open/close applications')
    .addStringOption((o) => o.setName('name').setDescription('Application').setRequired(true).setAutocomplete(true))
    .addBooleanOption((o) => o.setName('open').setDescription('Open?').setRequired(true)))
  .addSubcommand((s) => s.setName('list').setDescription('Show applications and their questions'));

const suggest = (i) => {
  const q = i.options.getFocused().toLowerCase();
  return i.respond(Object.keys(appsOf(i.guild)).filter((n) => n.includes(q)).slice(0, 25).map((n) => ({ name: n, value: n })));
};

module.exports = {
  active,
  commands: [
    {
      data: adminCmd,
      autocomplete: suggest,
      async execute(i) {
        const apps = appsOf(i.guild), sub = i.options.getSubcommand();
        const name = i.options.getString('name') ? key(i.options.getString('name')) : null;
        if (sub === 'create') {
          if (apps[name]) return i.reply({ flags: EPH, content: 'That application already exists.' });
          apps[name] = { questions: [], reviewChannel: null, acceptRole: null, open: true };
          db.save();
          return i.reply({ flags: EPH, embeds: [embed('ok', 'Created', `Add questions with \`/appadmin addquestion\`, set \`/appadmin review\`, then members use \`/apply ${name}\`.`)] });
        }
        if (sub === 'list') {
          const body = Object.entries(apps).map(([n, a]) => `**${n}** (${a.open ? 'open' : 'closed'}) - review: ${a.reviewChannel ? `<#${a.reviewChannel}>` : '⚠️ not set'}, role: ${a.acceptRole ? `<@&${a.acceptRole}>` : 'none'}\n${a.questions.map((q, k) => `  ${k + 1}. ${q.slice(0, 80)}`).join('\n') || '  *no questions*'}`).join('\n\n') || 'No applications yet.';
          return i.reply({ flags: EPH, embeds: [embed('info', 'Applications', body.slice(0, 4000))] });
        }
        const app = apps[name];
        if (!app) return i.reply({ flags: EPH, content: 'No application with that name.' });
        if (sub === 'delete') delete apps[name];
        if (sub === 'addquestion') app.questions.push(i.options.getString('question'));
        if (sub === 'removequestion') {
          const n = i.options.getInteger('number');
          if (n > app.questions.length) return i.reply({ flags: EPH, content: `Only ${app.questions.length} questions.` });
          app.questions.splice(n - 1, 1);
        }
        if (sub === 'review') app.reviewChannel = i.options.getChannel('channel').id;
        if (sub === 'role') app.acceptRole = i.options.getRole('role').id;
        if (sub === 'toggle') app.open = i.options.getBoolean('open');
        db.save();
        return i.reply({ flags: EPH, embeds: [embed('ok', 'Updated', sub === 'delete' ? 'Deleted.' : `**${name}** now has **${app.questions.length}** question(s).`)] });
      },
    },
    {
      data: new SlashCommandBuilder().setName('apply').setDescription('Start an application (in DMs)')
        .addStringOption((o) => o.setName('name').setDescription('Which application').setRequired(true).setAutocomplete(true)),
      autocomplete: suggest,
      async execute(i) {
        const name = key(i.options.getString('name')), app = appsOf(i.guild)[name];
        if (!app) return i.reply({ flags: EPH, content: 'That application doesn\'t exist.' });
        if (perms.serverBlacklist(i.guild).users[i.user.id]) return i.reply({ flags: EPH, content: '⛔ You\'re blacklisted from applying here.' });
        if (!app.open) return i.reply({ flags: EPH, content: '🔒 Applications are closed right now.' });
        if (!app.questions.length || !app.reviewChannel) return i.reply({ flags: EPH, content: 'This application isn\'t fully set up yet.' });
        if (active.has(i.user.id)) return i.reply({ flags: EPH, content: 'You already have an application in progress - check your DMs.' });
        try { await i.user.send('👋 Starting your application...'); }
        catch { return i.reply({ flags: EPH, content: '❌ I can\'t DM you. Enable DMs from server members and try again.' }); }
        await i.reply({ flags: EPH, content: '📬 Check your DMs!' });
        runApplication(i.user, i.guild, name, app).catch((e) => { active.delete(i.user.id); console.error(e); });
      },
    },
  ],

  async onInteraction(i) {
    if (!i.isButton() || !i.customId.startsWith('app:')) return false;
    if (!i.memberPermissions.has(PermissionFlagsBits.ManageGuild)) { await i.reply({ flags: EPH, content: 'You need Manage Server.' }); return true; }
    const [, action, uid, ...rest] = i.customId.split(':');
    const name = rest.join(':'), app = appsOf(i.guild)[name];
    const member = await i.guild.members.fetch(uid).catch(() => null);
    const accepted = action === 'accept';
    if (accepted && app?.acceptRole && member) await member.roles.add(app.acceptRole).catch(() => {});
    member?.send({ embeds: [embed(accepted ? 'ok' : 'err', accepted ? '🎉 Application accepted!' : 'Application denied', `Your **${name}** application in **${i.guild.name}** was ${accepted ? 'accepted' : 'denied'}.`)] }).catch(() => {});
    await i.update({
      embeds: [...i.message.embeds.map((e) => ({ ...e.toJSON(), color: accepted ? 0x57f287 : 0xed4245, footer: { text: `${accepted ? 'Accepted' : 'Denied'} by ${i.user.username}` } }))],
      components: [],
    });
    return true;
  },
};
