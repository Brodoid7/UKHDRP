const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, AttachmentBuilder } = require('discord.js');
const db = require('../lib/db');
const { embed, EPH } = require('../lib/util');
const { active: applying } = require('./applications');
const perms = require('../lib/perms');

const DEF = { category: null, logChannel: null, staffRole: null, blocked: [], threads: {} };
const cfgOf = (g) => db.get(g.id, 'modmail', DEF);
const threadUser = (cfg, chId) => Object.entries(cfg.threads).find(([, c]) => c === chId)?.[0];

const files = (m) => m.attachments.map((a) => a.url);

async function handleDM(client, msg) {
  if (applying.has(msg.author.id)) return;
  const guild = client.guilds.cache.get(process.env.GUILD_ID) || client.guilds.cache.first();
  if (!guild) return;
  if (perms.isBotBlacklisted(msg.author.id)) return;
  const cfg = cfgOf(guild);
  if (!cfg.category) return msg.reply('📪 Modmail isn\'t set up yet.').catch(() => {});
  if (cfg.blocked.includes(msg.author.id) || perms.serverBlacklist(guild).users[msg.author.id]) return msg.reply('🚫 You can\'t use modmail.').catch(() => {});

  let ch = guild.channels.cache.get(cfg.threads[msg.author.id]);
  if (!ch) {
    ch = await guild.channels.create({
      name: `mail-${msg.author.username}`.replace(/[^a-z0-9-_]/gi, '').toLowerCase().slice(0, 90) || `mail-${msg.author.id}`,
      parent: cfg.category, topic: `Modmail • ${msg.author.tag} • ${msg.author.id}`, type: ChannelType.GuildText,
    }).catch(() => null);
    if (!ch) return msg.reply('⚠️ Couldn\'t open a ticket - please tell a staff member.').catch(() => {});
    cfg.threads[msg.author.id] = ch.id; db.save();
    const m = await guild.members.fetch(msg.author.id).catch(() => null);
    await ch.send({
      content: cfg.staffRole ? `<@&${cfg.staffRole}> new modmail!` : undefined,
      allowedMentions: { roles: cfg.staffRole ? [cfg.staffRole] : [] },
      embeds: [embed('info', '📬 New modmail thread', [
        `**User:** ${msg.author} (${msg.author.id})`,
        `**Account created:** <t:${Math.floor(msg.author.createdTimestamp / 1000)}:R>`,
        m ? `**Joined:** <t:${Math.floor(m.joinedTimestamp / 1000)}:R>` : '',
        '',
        'Type here to reply. Start a message with `//` for an internal note. Use `/modmail close` when done.',
      ].join('\n')).setThumbnail(msg.author.displayAvatarURL())],
    });
    await msg.reply({ embeds: [embed('ok', '📨 Message sent', 'Staff will reply here in DMs. Keep chatting to add more.')] }).catch(() => {});
  }
  const e = embed('info', null, msg.content || '*(attachment only)*').setAuthor({ name: msg.author.tag, iconURL: msg.author.displayAvatarURL() });
  if (files(msg).length) e.addFields({ name: 'Attachments', value: files(msg).join('\n').slice(0, 1000) });
  await ch.send({ embeds: [e] });
  msg.react('✅').catch(() => {});
}

async function handleStaff(msg) {
  const cfg = cfgOf(msg.guild);
  const uid = threadUser(cfg, msg.channel.id);
  if (!uid || msg.content.startsWith('//')) return;
  const user = await msg.client.users.fetch(uid).catch(() => null);
  const e = embed('info', null, msg.content || '*(attachment only)*').setAuthor({ name: `${msg.guild.name} Staff`, iconURL: msg.guild.iconURL() });
  if (files(msg).length) e.addFields({ name: 'Attachments', value: files(msg).join('\n').slice(0, 1000) });
  const sent = await user?.send({ embeds: [e] }).then(() => true).catch(() => false);
  msg.react(sent ? '✅' : '❌').catch(() => {});
}

async function transcript(channel) {
  let all = [], before;
  for (let n = 0; n < 10; n++) {
    const batch = await channel.messages.fetch({ limit: 100, before });
    if (!batch.size) break;
    all = all.concat([...batch.values()]); before = batch.last().id;
  }
  return all.reverse().map((m) => `[${new Date(m.createdTimestamp).toISOString()}] ${m.author.tag}: ${m.content || m.embeds[0]?.description || ''} ${m.embeds[0]?.fields?.[0]?.value || ''}`).join('\n');
}

module.exports = {
  init(client) {
    client.on('messageCreate', (msg) => {
      if (msg.author.bot) return;
      return (msg.guild ? handleStaff(msg) : handleDM(client, msg)).catch((e) => console.error('modmail:', e));
    });
    // user left the server or channel deleted manually -> forget thread
    client.on('channelDelete', (ch) => {
      if (!ch.guild) return;
      const cfg = cfgOf(ch.guild), uid = threadUser(cfg, ch.id);
      if (uid) { delete cfg.threads[uid]; db.save(); }
    });
  },
  commands: [{
    data: new SlashCommandBuilder().setName('modmail').setDescription('Modmail system')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
      .addSubcommand((s) => s.setName('setup').setDescription('Configure modmail (Manage Server)')
        .addChannelOption((o) => o.setName('category').setDescription('Category for tickets').addChannelTypes(ChannelType.GuildCategory).setRequired(true))
        .addRoleOption((o) => o.setName('staffrole').setDescription('Role to ping on new threads'))
        .addChannelOption((o) => o.setName('logs').setDescription('Transcript channel').addChannelTypes(ChannelType.GuildText)))
      .addSubcommand((s) => s.setName('close').setDescription('Close this thread').addStringOption((o) => o.setName('reason').setDescription('Reason shown to the user')))
      .addSubcommand((s) => s.setName('block').setDescription('Block a user from modmail').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
      .addSubcommand((s) => s.setName('unblock').setDescription('Unblock a user').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))),
    async execute(i) {
      const cfg = cfgOf(i.guild), sub = i.options.getSubcommand();
      if (sub === 'setup') {
        if (!i.memberPermissions.has(PermissionFlagsBits.ManageGuild)) return i.reply({ flags: EPH, content: 'Needs Manage Server.' });
        cfg.category = i.options.getChannel('category').id;
        cfg.staffRole = i.options.getRole('staffrole')?.id ?? cfg.staffRole;
        cfg.logChannel = i.options.getChannel('logs')?.id ?? cfg.logChannel;
        db.save();
        return i.reply({ flags: EPH, embeds: [embed('ok', 'Modmail configured', 'Tip: make the category private so only staff can see tickets. Users DM me to open a thread.')] });
      }
      if (sub === 'block' || sub === 'unblock') {
        const u = i.options.getUser('user').id;
        cfg.blocked = cfg.blocked.filter((x) => x !== u);
        if (sub === 'block') cfg.blocked.push(u);
        db.save();
        return i.reply({ flags: EPH, content: sub === 'block' ? '🚫 Blocked.' : '✅ Unblocked.' });
      }
      const uid = threadUser(cfg, i.channel.id);
      if (!uid) return i.reply({ flags: EPH, content: 'Use this inside a modmail thread.' });
      await i.reply('🔒 Closing thread...');
      const reason = i.options.getString('reason') || 'No reason given';
      const text = await transcript(i.channel);
      const log = i.guild.channels.cache.get(cfg.logChannel);
      await log?.send({ embeds: [embed('info', '📁 Modmail closed', `**User:** <@${uid}>\n**Closed by:** ${i.user}\n**Reason:** ${reason}`)], files: [new AttachmentBuilder(Buffer.from(text), { name: `transcript-${uid}.txt` })] }).catch(() => {});
      (await i.client.users.fetch(uid).catch(() => null))?.send({ embeds: [embed('warn', '🔒 Thread closed', `${reason}\n\nDM me again anytime to open a new one.`)] }).catch(() => {});
      delete cfg.threads[uid]; db.save();
      setTimeout(() => i.channel.delete('Modmail closed').catch(() => {}), 4000);
    },
  }],
};
