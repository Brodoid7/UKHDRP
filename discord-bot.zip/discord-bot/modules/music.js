const { SlashCommandBuilder } = require('discord.js');
const { Player, useQueue, QueueRepeatMode } = require('discord-player');
const { DefaultExtractors } = require('@discord-player/extractor');
const { YoutubeiExtractor } = require('discord-player-youtubei');
const { embed, EPH } = require('../lib/util');

let player;
const q = (i) => useQueue(i.guild.id);
const needQueue = (i, queue) => (!queue || !queue.isPlaying()) && (i.reply({ flags: EPH, content: '🔇 Nothing is playing.' }), true);
const needVoice = (i) => {
  const vc = i.member.voice.channel;
  const mine = i.guild.members.me.voice.channelId;
  if (!vc) return i.reply({ flags: EPH, content: 'Join a voice channel first.' }), true;
  if (mine && mine !== vc.id) return i.reply({ flags: EPH, content: 'You need to be in my voice channel.' }), true;
};

module.exports = {
  async init(client) {
    player = new Player(client);
    await player.extractors.register(YoutubeiExtractor, {});
    await player.extractors.loadMulti(DefaultExtractors);
    player.events.on('playerStart', (queue, t) =>
      queue.metadata?.send({ embeds: [embed('info', '🎶 Now playing', `**[${t.title}](${t.url})**\nby ${t.author} • ${t.duration}\nRequested by ${t.requestedBy ?? 'unknown'}`).setThumbnail(t.thumbnail)] }).catch(() => {}));
    player.events.on('emptyQueue', (queue) => queue.metadata?.send('✅ Queue finished.').catch(() => {}));
    player.events.on('error', (_q, e) => console.error('player error:', e));
    player.events.on('playerError', (_q, e) => console.error('track error:', e));
  },
  commands: [
    {
      data: new SlashCommandBuilder().setName('play').setDescription('Play a song (name or YouTube/Spotify/SoundCloud link)')
        .addStringOption((o) => o.setName('query').setDescription('Song name or URL').setRequired(true)),
      async execute(i) {
        if (needVoice(i)) return;
        await i.deferReply();
        try {
          const { track } = await player.play(i.member.voice.channel, i.options.getString('query'), {
            nodeOptions: { metadata: i.channel, volume: 50, selfDeaf: true, leaveOnEmpty: true, leaveOnEmptyCooldown: 60000, leaveOnEnd: true, leaveOnEndCooldown: 60000 },
            requestedBy: i.user,
          });
          return i.editReply({ embeds: [embed('ok', null, `➕ Queued **[${track.title}](${track.url})**`)] });
        } catch (e) { console.error(e); return i.editReply(`❌ Couldn't play that: ${e.message?.slice(0, 150) || 'unknown error'}`); }
      },
    },
    { data: new SlashCommandBuilder().setName('skip').setDescription('Skip the current song'),
      execute(i) { const queue = q(i); if (needVoice(i) || needQueue(i, queue)) return; queue.node.skip(); return i.reply('⏭️ Skipped.'); } },
    { data: new SlashCommandBuilder().setName('stop').setDescription('Stop music and leave'),
      execute(i) { const queue = q(i); if (needVoice(i) || needQueue(i, queue)) return; queue.delete(); return i.reply('⏹️ Stopped.'); } },
    { data: new SlashCommandBuilder().setName('pause').setDescription('Pause or resume'),
      execute(i) { const queue = q(i); if (needVoice(i) || needQueue(i, queue)) return; const p = !queue.node.isPaused(); queue.node.setPaused(p); return i.reply(p ? '⏸️ Paused.' : '▶️ Resumed.'); } },
    { data: new SlashCommandBuilder().setName('volume').setDescription('Set volume').addIntegerOption((o) => o.setName('percent').setDescription('1-100').setMinValue(1).setMaxValue(100).setRequired(true)),
      execute(i) { const queue = q(i); if (needVoice(i) || needQueue(i, queue)) return; queue.node.setVolume(i.options.getInteger('percent')); return i.reply(`🔊 Volume: **${i.options.getInteger('percent')}%**`); } },
    { data: new SlashCommandBuilder().setName('loop').setDescription('Loop mode')
        .addStringOption((o) => o.setName('mode').setDescription('Mode').setRequired(true).addChoices({ name: 'off', value: 'off' }, { name: 'song', value: 'track' }, { name: 'queue', value: 'queue' })),
      execute(i) {
        const queue = q(i); if (needVoice(i) || needQueue(i, queue)) return;
        const m = i.options.getString('mode');
        queue.setRepeatMode({ off: QueueRepeatMode.OFF, track: QueueRepeatMode.TRACK, queue: QueueRepeatMode.QUEUE }[m]);
        return i.reply(`🔁 Loop: **${m}**`);
      } },
    { data: new SlashCommandBuilder().setName('shuffle').setDescription('Shuffle the queue'),
      execute(i) { const queue = q(i); if (needVoice(i) || needQueue(i, queue)) return; queue.tracks.shuffle(); return i.reply('🔀 Shuffled.'); } },
    { data: new SlashCommandBuilder().setName('queue').setDescription('Show the queue'),
      execute(i) {
        const queue = q(i); if (needQueue(i, queue)) return;
        const next = queue.tracks.toArray().slice(0, 10).map((t, n) => `**${n + 1}.** ${t.title} (${t.duration})`).join('\n') || '*empty*';
        return i.reply({ embeds: [embed('info', '📜 Queue', `**Now:** ${queue.currentTrack.title}\n\n${next}${queue.tracks.size > 10 ? `\n…and ${queue.tracks.size - 10} more` : ''}`)] });
      } },
    { data: new SlashCommandBuilder().setName('nowplaying').setDescription('Current song'),
      execute(i) {
        const queue = q(i); if (needQueue(i, queue)) return;
        const t = queue.currentTrack;
        return i.reply({ embeds: [embed('info', '🎶 Now playing', `**[${t.title}](${t.url})**\n${queue.node.createProgressBar()}`).setThumbnail(t.thumbnail)] });
      } },
  ],
};
