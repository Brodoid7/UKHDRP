const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../lib/db');
const perms = require('../lib/perms');
const { embed, log, EPH } = require('../lib/util');

const LV = { low: 1, medium: 2, high: 3 };
const ICON = { low: '🟡', medium: '🟠', high: '🔴' };
const serverFlags = (g) => db.get(g.id, 'flags', {});
const globalFlags = () => db.get('global', 'flags', {});
const cfgOf = (g) => db.get(g.id, 'flagCfg', { action: 'none', minLevel: 'high' });
const fmt = (f, n) => `${ICON[f.level]} **#${n + 1}** ${f.reason} - <@${f.by}> <t:${Math.floor(f.ts / 1000)}:R>`;

module.exports = {
  init(client) {
    // Alert (and optionally act) when a flagged user joins
    client.on('guildMemberAdd', async (m) => {
      const sf = serverFlags(m.guild)[m.id] || [], gf = globalFlags()[m.id] || [];
      if (!sf.length && !gf.length) return;
      const all = [...sf, ...gf], top = Math.max(...all.map((f) => LV[f.level]));
      const topName = Object.keys(LV).find((k) => LV[k] === top);
      log(m.guild, embed(top >= 3 ? 'err' : 'warn', '🚩 Flagged user joined', [
        `${m} (${m.id}) - highest level ${ICON[topName]} **${topName}**`,
        ...sf.map((f, n) => `Server: ${fmt(f, n)}`), ...gf.map((f, n) => `Global: ${fmt(f, n)}`),
      ].join('\n').slice(0, 4000)));
      const cfg = cfgOf(m.guild);
      if (cfg.action === 'none' || top < LV[cfg.minLevel] || perms.isWhitelisted(m.guild, m.id)) return;
      const why = 'Flagged user auto-action';
      try {
        if (cfg.action === 'ban') await m.ban({ reason: why });
        else if (cfg.action === 'kick') await m.kick(why);
        else await m.timeout(60 * 60000, why);
      } catch { /* hierarchy */ }
    });
  },
  commands: [{
    data: new SlashCommandBuilder().setName('flag').setDescription('Flag risky users (server flags or global bot-staff flags)')
      .addSubcommand((s) => s.setName('add').setDescription('Flag a user')
        .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))
        .addStringOption((o) => o.setName('level').setDescription('Severity').setRequired(true).addChoices({ name: '🟡 low', value: 'low' }, { name: '🟠 medium', value: 'medium' }, { name: '🔴 high', value: 'high' }))
        .addStringOption((o) => o.setName('reason').setDescription('Why').setRequired(true).setMaxLength(300))
        .addStringOption((o) => o.setName('scope').setDescription('Default: server').addChoices({ name: 'server', value: 'server' }, { name: 'global (bot mod+)', value: 'global' })))
      .addSubcommand((s) => s.setName('remove').setDescription('Remove a flag')
        .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))
        .addIntegerOption((o) => o.setName('number').setDescription('Flag # (omit = clear all)').setMinValue(1))
        .addStringOption((o) => o.setName('scope').setDescription('Default: server').addChoices({ name: 'server', value: 'server' }, { name: 'global (bot mod+)', value: 'global' })))
      .addSubcommand((s) => s.setName('check').setDescription("Show a user's flags").addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
      .addSubcommand((s) => s.setName('list').setDescription('List flagged users').addStringOption((o) => o.setName('scope').setDescription('Default: server').addChoices({ name: 'server', value: 'server' }, { name: 'global (bot mod+)', value: 'global' })))
      .addSubcommand((s) => s.setName('config').setDescription('Auto-action when flagged users join (Manage Server)')
        .addStringOption((o) => o.setName('action').setDescription('Action').setRequired(true).addChoices({ name: 'none (alert only)', value: 'none' }, { name: '1h timeout', value: 'timeout' }, { name: 'kick', value: 'kick' }, { name: 'ban', value: 'ban' }))
        .addStringOption((o) => o.setName('min_level').setDescription('Lowest level that triggers it').addChoices({ name: 'low', value: 'low' }, { name: 'medium', value: 'medium' }, { name: 'high', value: 'high' }))),
    async execute(i) {
      const sub = i.options.getSubcommand();
      const global = i.options.getString('scope') === 'global';
      const mention = { parse: [] };

      if (sub === 'config') {
        if (!i.memberPermissions.has(PermissionFlagsBits.ManageGuild)) return i.reply({ flags: EPH, content: '🔒 Needs Manage Server.' });
        const cfg = cfgOf(i.guild);
        cfg.action = i.options.getString('action'); cfg.minLevel = i.options.getString('min_level') || cfg.minLevel; db.save();
        return i.reply({ flags: EPH, embeds: [embed('ok', '🚩 Flag config', `Action: **${cfg.action}** for level **${cfg.minLevel}**+. Alerts go to your \`/setlogs\` channel.`)] });
      }
      if (sub === 'check') {
        if (!i.memberPermissions.has(PermissionFlagsBits.ModerateMembers) && perms.rankOf(i.user.id) < 1) return i.reply({ flags: EPH, content: '🔒 Needs Moderate Members.' });
        const u = i.options.getUser('user'), sf = serverFlags(i.guild)[u.id] || [], gf = globalFlags()[u.id] || [];
        return i.reply({ flags: EPH, allowedMentions: mention, embeds: [embed(sf.length || gf.length ? 'warn' : 'ok', `🚩 Flags: ${u.tag}`,
          [`**Server (${sf.length})**`, ...sf.map(fmt), '', `**Global (${gf.length})**`, ...gf.map(fmt)].join('\n').slice(0, 4000))] });
      }
      // everything below: server scope needs Moderate Members, global scope needs bot mod
      if (global ? perms.denyUnless(i, 'mod') : !i.memberPermissions.has(PermissionFlagsBits.ModerateMembers) && (i.reply({ flags: EPH, content: '🔒 Needs Moderate Members.' }), true)) return;
      const store = global ? globalFlags() : serverFlags(i.guild);

      if (sub === 'list') {
        const rows = Object.entries(store).map(([id, f]) => `<@${id}> - ${f.length} flag(s), top ${ICON[f.reduce((a, b) => (LV[b.level] > LV[a] ? b.level : a), 'low')]}`).join('\n') || 'None.';
        return i.reply({ flags: EPH, allowedMentions: mention, embeds: [embed('info', `🚩 ${global ? 'Global' : 'Server'} flags`, rows.slice(0, 4000))] });
      }
      const u = i.options.getUser('user');
      if (sub === 'add') {
        if (u.bot || perms.isGlobalWhitelisted(u.id)) return i.reply({ flags: EPH, content: 'You can\'t flag that user.' });
        const arr = (store[u.id] ||= []);
        if (arr.length >= 20) return i.reply({ flags: EPH, content: 'That user already has 20 flags.' });
        arr.push({ level: i.options.getString('level'), reason: i.options.getString('reason'), by: i.user.id, ts: Date.now() });
        db.save();
        log(i.guild, embed('warn', '🚩 Flag added', `${u.tag} (${u.id}) - ${global ? 'global' : 'server'}\n${fmt(arr.at(-1), arr.length - 1)}`));
        return i.reply({ flags: EPH, embeds: [embed('ok', null, `🚩 Flagged **${u.tag}** (${global ? 'global' : 'server'}, ${arr.length} total).`)] });
      }
      // remove
      const arr = store[u.id], n = i.options.getInteger('number');
      if (!arr?.length) return i.reply({ flags: EPH, content: 'No flags to remove.' });
      if (n) { if (n > arr.length) return i.reply({ flags: EPH, content: `Only ${arr.length} flag(s).` }); arr.splice(n - 1, 1); if (!arr.length) delete store[u.id]; }
      else delete store[u.id];
      db.save();
      return i.reply({ flags: EPH, embeds: [embed('ok', null, n ? `Removed flag #${n}.` : `Cleared all flags for **${u.tag}**.`)] });
    },
  }],
};
