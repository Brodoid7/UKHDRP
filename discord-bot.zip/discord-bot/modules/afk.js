const { SlashCommandBuilder } = require('discord.js');
const db = require('../lib/db');
const { embed } = require('../lib/util');

const store = (g) => db.get(g.id, 'afk', {});

module.exports = {
  init(client) {
    client.on('messageCreate', async (msg) => {
      if (!msg.guild || msg.author.bot) return;
      const afk = store(msg.guild);
      if (afk[msg.author.id]) {
        const since = afk[msg.author.id].since;
        delete afk[msg.author.id]; db.save();
        msg.reply({ content: `👋 Welcome back ${msg.author}! You were AFK since <t:${Math.floor(since / 1000)}:R>.`, allowedMentions: { repliedUser: false } })
          .then((m) => setTimeout(() => m.delete().catch(() => {}), 8000)).catch(() => {});
      }
      const lines = msg.mentions.users.filter((u) => afk[u.id] && u.id !== msg.author.id)
        .map((u) => `💤 **${u.displayName}** is AFK: ${afk[u.id].reason} (<t:${Math.floor(afk[u.id].since / 1000)}:R>)`);
      if (lines.length) msg.reply({ content: lines.join('\n'), allowedMentions: { parse: [] } }).catch(() => {});
    });
  },
  commands: [{
    data: new SlashCommandBuilder().setName('afk').setDescription('Set yourself AFK')
      .addStringOption((o) => o.setName('reason').setDescription('Why?').setMaxLength(150)),
    async execute(i) {
      store(i.guild)[i.user.id] = { reason: i.options.getString('reason') || 'AFK', since: Date.now() };
      db.save();
      return i.reply({ embeds: [embed('ok', null, `💤 ${i.user}, you're now AFK. I'll clear it when you next talk.`)], allowedMentions: { parse: [] } });
    },
  }],
};
